/**
 * @author Matthew Samms
 */
export class Hero {
    /**
     * Constructor for the hero
     * @param id The id of the Hero
     * @param name The name of the Hero
     */
    constructor(public id: number, public name: string) {
    }
}
