/**
 * Imports for the hero-details component
 */
import { Component, OnInit, Input } from '@angular/core';
import { Hero } from '../hero';

/**
 * This is the imported component object
 * files will be present in the hero-details subfolder
 */
@Component({
  selector: 'app-hero-details',
  templateUrl: './hero-details.component.html',
  styleUrls: ['./hero-details.component.css']
})
export class HeroDetailsComponent implements OnInit {
  /**
   * This input sends a Hero into the hero-details component
   * when the component is called
   */
  @Input()hero: Hero;

  constructor() { }

  ngOnInit() {
  }

}
